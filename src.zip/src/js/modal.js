var modal = document.getElementById("myModal");
// Get the button that opens the modal
var btn = document.getElementById("myBtn");
// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];
// When the user clicks the button, open the modal 
btn.onclick = function() {
 /* modal.style.display = "block";
     var x=document.getElementById("myBtn").parentNode.parentNode;
    var y=x.children[0].innerHTML;
	
    
  document.getElementById("content_title").innerHTML = y;
    
	var pic = x.parentNode.children[0].children[0].src;
	document.getElementById("product_pic").src = pic;
	//console.log(pic); */
	modal.style.display = "block";
	var x=document.getElementById("myBtn");
	var title = x.parentNode.children[2].innerHTML;
	document.getElementById("content_title").innerHTML = title;
var pic =x.parentNode.children[1].children[0].src;
document.getElementById("product_pic").src = pic;
var id =x.parentNode.getAttribute("productid");
	/* console.log(id); */
var rate = x.parentNode.children[0].children[1].children[0].innerHTML;
	
	document.getElementById("pro_price").innerHTML = rate;
	
	document.getElementById("pro_id").innerHTML = id;
}
// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}