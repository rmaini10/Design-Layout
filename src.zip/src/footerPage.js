import React from "react";

const FooterPage = () =>{
    return(
    <footer  className="footer">
        <div className="footer_content">
            <div className="section_container">
                <div className="container">
                    <div className="row">

                        
                        <div className="col-xxl-3 col-md-4 footer_col">
                            <div className="footer_about">
                                
                                <div className="footer_logo">
                                    <a href="/#">
                                        <div>a<span>star</span></div>
                                    </a>
                                </div>
                                <div className="footer_about_text">
                                    <p>Donec vitae purus nunc. Morbi faucibus erat sit amet congue mattis. Nullam fringilla faucibus urna, id dapibus erat iaculis ut. Integer ac sem.</p>
                                </div>
                                
	
                            </div>
                        </div>

                       
                        <div className="col-xxl-3 col-md-4 footer_col">
                            <div className="footer_questions">
                                <div className="footer_title">questions</div>
                                <div className="footer_list">
                                    <ul>
                                        <li><a href="/#">About us</a></li>
                                        <li><a href="/#">Track Orders</a></li>
                                        <li><a href="/#">Return Policy</a></li>
                                        <li><a href="/#">Contact Us</a></li>
                                        <li><a href="/#">FAQs</a></li>
                                        <li><a href="/#">Manual</a></li>
                                        {/* <li><a href="/#">Partners</a></li>
                                        <li><a href="/#">Bloggers</a></li>
                                        <li><a href="/#">Support</a></li>
                                        <li><a href="/#">Terms of Use</a></li>s
                                        <li><a href="/#">Press</a></li> */}
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div className="col-xxl-3 col-md-4 footer_col">
                            <div className="footer_contact">
                                <div className="footer_title">Follow us on:</div>
                                <div className="footer_contact_list">
                                    <ul>
                                        <li className="d-flex flex-row align-items-start justify-content-start"> <a href="https://www.instagram.com/step_beyond_ordinary/?igshid=1gk7m954ylauf">
                                                <div className="footer_social_item d-flex flex-row align-items-center justify-content-start">
                                                    <div className="footer_social_icon"><i className="fa fa-instagram" aria-hidden="true"></i></div>
                                                    <div className="footer_social_title">instagram</div>
                                                </div>
                                            </a>
                                        </li>
                                        <li className="d-flex flex-row align-items-start justify-content-start"> <a href="https://www.facebook.com/Kidstation-Step_beyond_Ordinary-2223183277758185/">
                                                <div className="footer_social_item d-flex flex-row align-items-center justify-content-start">
                                                    <div className="footer_social_icon"><i className="fa fa-facebook" aria-hidden="true"></i></div>
                                                    <div className="footer_social_title">facebook</div>
                                                </div>
                                            </a>
                                        </li>
                                        
										
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        

    </footer>

    );
}
export default FooterPage;
