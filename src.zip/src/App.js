import React from 'react';
import FooterPage from './footerPage'
import HeaderPage from './headerPage'
import "./bootstrap/bootstrap.css";
import "./css/main_styles.css";
import "./css/responsive.css";
import '@fortawesome/fontawesome-free/css/fontawesome.min.css';
// import $ from 'jquery';
// import './js/custom.js';


import './App.css';


function App() {
  return (
    <div className="App super_container">
      <link rel="stylesheet" type="text/css" href="./plugins/OwlCarousel2-2.2.1/owl.carousel.css"></link>
    <link rel="stylesheet" type="text/css" href="./plugins/OwlCarousel2-2.2.1/owl.theme.default.css"></link>
    <link rel="stylesheet" type="text/css" href="./plugins/OwlCarousel2-2.2.1/animate.css"></link>
     <link href="./plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css"></link>
    <script src=".js/jquery-3.2.1.min.js"></script>
    <script src="./styles/bootstrap-4.1.3/popper.js"></script>
    <script src="./styles/bootstrap-4.1.3/bootstrap.min.js"></script>
    <script src="./plugins/greensock/TweenMax.min.js"></script>
    <script src="./plugins/greensock/TimelineMax.min.js"></script>
    <script src="./plugins/scrollmagic/ScrollMagic.min.js"></script>
    <script src="./plugins/greensock/animation.gsap.min.js"></script>
    <script src="./plugins/greensock/ScrollToPlugin.min.js"></script>
    <script src="./plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
    <script src="./plugins/easing/easing.js"></script>
    <script src="./plugins/parallax-js-master/parallax.min.js"></script>
    <script src="./plugins/Isotope/isotope.pkgd.min.js"></script>
    <script src="./plugins/Isotope/fitcolumns.js"></script>
    <script src="./js/custom.js"></script>
     <HeaderPage/>
     <FooterPage/>
    </div>
  );
}

export default App;
