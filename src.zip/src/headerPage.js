import React, { Component } from 'react';
import '@fortawesome/fontawesome-free/css/fontawesome.min.css';
// import Bag from './images/bag.png';
// import $ from 'jquery';
class HeaderPage extends Component{
    
    render(){
        return(
           
            
            <headerpage>
          
   <header className="header">
    <div className="header_content d-flex flex-row align-items-center justify-content-start">

       
        <div className="hamburger menu_mm"><i className="fa fa-bars menu_mm" aria-hidden="true"></i></div>

      
        <div className="header_logo">
            <a href="/#">
                <div>a<span>star</span></div>
            </a>
        </div>

       
        <nav className="header_nav">
            <ul className="d-flex flex-row align-items-center justify-content-start">
            <li className="menu_mm"><a href="/#">Home</a></li>
            <li className="menu_mm"><a href="/#">Shop</a></li>
            <li className="menu_mm"><a href="/#">Categories</a></li>
            <li className="menu_mm"><a href="/#">Bestselling</a></li>
            <li className="menu_mm"><a href="/#">What Our Customers Say</a></li>
            <li className="menu_mm"><a href="/#">Festive Items</a></li>
            <li className="menu_mm"><a href="/#">Contact Us</a></li>
            </ul>
        </nav>

        
        <div className="header_extra ml-auto d-flex flex-row align-items-center justify-content-start"> 
            <div className="cart d-flex flex-row align-items-center justify-content-start">
                <div className="cart_icon"><a href="/#">
                        <img src="{Bag}" alt=""/></a>
                        <div className="cart_num">2</div>
                </div>
            </div>
        </div>
        </div>
</header>



<div className="menu d-flex flex-column align-items-start justify-content-start menu_mm trans_400">
    <div className="menu_close_container">
        <div className="menu_close">
            <div></div>
            <div></div>
        </div>
    </div>
    <div className="menu_top d-flex flex-row align-items-center justify-content-start">


    </div>
    <div className="menu_search">
        <form action="/#" className="header_search_form menu_mm">
            <input type="search" className="search_input menu_mm" placeholder="Search" required="required"/>
            <button className="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
                <i className="fa fa-search menu_mm" aria-hidden="true"></i>
            </button>
        </form>
    </div>
    <nav className="menu_nav">
        <ul className="menu_mm">
            <li className="menu_mm"><a href="index.php">Home</a></li>
            <li className="menu_mm"><a href="category_try.php">Shop</a></li>
            <li className="menu_mm"><a href="/#">Categories</a></li>
            <li className="menu_mm"><a href="/#">Bestselling</a></li>
            <li className="menu_mm"><a href="/#">What Our Customers Say</a></li>
            <li className="menu_mm"><a href="/#">Festive Items</a></li>
            <li className="menu_mm"><a href="/#">Contact Us</a></li>
        </ul>
    </nav>
    <div className="menu_extra">
        <div className="menu_social">
            <ul>
                <li><a href="/#"><i className="fa fa-pinterest" aria-hidden="true"></i>pinterest</a></li>
                <li><a href="/#"><i className="fa fa-facebook" aria-hidden="true"></i>facebook</a></li>
                <li><a href="/#"><i className="fa fa-instagram" aria-hidden="true"></i>instagram</a></li>
                <li><a href="/#"><i className="fa fa-twitter" aria-hidden="true"></i>twitter</a></li>
            </ul>
        </div>
    </div>
</div>



<div className="sidebar">

   
    <div className="info">
        <div className="info_content d-flex flex-row align-items-center justify-content-start">

   
        </div>
    </div>


    <div className="sidebar_logo">
        <a href="/#">
            <div>a<span>star</span></div>
        </a>
    </div>


    <nav className="sidebar_nav">
        <ul>
            <li><a href="/#">home<i className="fa fa-angle-right" aria-hidden="true"></i></a></li>
            <li><a href="/#">shop<i className="fa fa-angle-right" aria-hidden="true"></i></a></li>
            <li><a href="/#">categories<i className="fa fa-angle-right" aria-hidden="true"></i></a></li>
            <li><a href="/#">best selling<i className="fa fa-angle-right" aria-hidden="true"></i></a></li>
            <li><a href="/#">what customers say<i className="fa fa-angle-right" aria-hidden="true"></i></a></li>
            <li><a href="/#">festive items<i className="fa fa-angle-right" aria-hidden="true"></i></a></li>
            <li><a href="/#">contact<i className="fa fa-angle-right" aria-hidden="true"></i></a></li>
        </ul>
    </nav>

   
    <div className="search">
        <form action="/#" className="search_form" id="sidebar_search_form">
            <input type="text" className="search_input" placeholder="Search" required="required"/>
            <button className="search_button"><i className="fa fa-search" aria-hidden="true"></i></button>
        </form>
    </div>

    
    <div className="cart d-flex flex-row align-items-center justify-content-start">
        <div className="cart_icon"><a href="cart.html">
                <img src="{Bag}" alt=""/>
                <div className="cart_num">2</div>
            </a></div>
        <div className="cart_text">bag</div>
        
    </div>
</div>

    
            </headerpage>
        )
    }
}
export default HeaderPage